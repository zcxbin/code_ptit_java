public class OS {
    static class PrimeNumbers implements Runnable {
        @Override
        public void run() {
            synchronized (System.out) {
                System.out.println("Số nguyên tố trong phạm vi 1000:");
                for (int i = 2; i <= 1000; i++) {
                    if (isPrime(i)) {
                        System.out.print(i + " ");
                    }
                }
                System.out.println();
            }
        }

        private boolean isPrime(int num) {
            if (num <= 1) return false;
            for (int i = 2; i <= Math.sqrt(num); i++) {
                if (num % i == 0) {
                    return false;
                }
            }
            return true;
        }
    }

    public static class PerfectNumbers implements Runnable {
        @Override
        public void run() {
            synchronized (System.out) {
                System.out.println("Số hoàn hảo trong phạm vi 10000:");
                for (int i = 1; i <= 10000; i++) {
                    if (isPerfect(i)) {
                        System.out.print(i + " ");
                    }
                }
                System.out.println();
            }
        }

        private boolean isPerfect(int num) {
            int sum = 0;
            for (int i = 1; i < num; i++) {
                if (num % i == 0) {
                    sum += i;
                }
            }
            return sum == num;
        }
    }

    static class DivisibleByThree implements Runnable {
        @Override
        public void run() {
            synchronized (System.out) {
                System.out.println("Số chia hết cho 3 trong phạm vi 2000:");
                for (int i = 1; i <= 2000; i++) {
                    if (i % 3 == 0) {
                        System.out.print(i + " ");
                    }
                }
                System.out.println();
            }
        }
    }

    public static void main(String[] args) {
        Thread primeThread = new Thread(new PrimeNumbers());
        Thread perfectNumberThread = new Thread(new PerfectNumbers());
        Thread divisibleByThreeThread = new Thread(new DivisibleByThree());

        primeThread.start();
        perfectNumberThread.start();
        divisibleByThreeThread.start();

        try {
            primeThread.join();
            perfectNumberThread.join();
            divisibleByThreeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
