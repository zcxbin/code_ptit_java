package J04014;

import java.util.Scanner;

public class J04014 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0){
            PhanSo ps1 = new PhanSo(sc.nextLong(), sc.nextLong());
            PhanSo ps2 = new PhanSo(sc.nextLong(), sc.nextLong());
            PhanSo ps3 = new PhanSo(1, 1);
            PhanSo ps4 = new PhanSo(1, 1);

            ps3.congPhanSo(ps1, ps2);
            ps3.rutGonPhanSo();
            ps1.nhanPhanSo(ps2);
            ps4.nhanPhanSo(ps3);
            ps4.nhanPhanSo(ps1);
            ps3.print();
            ps4.print();
            System.out.println();
        }
    }
}