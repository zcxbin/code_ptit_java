package J04014;

public class PhanSo {
    private long tuSo;
    private long mauSo;
    public PhanSo(long tuSo, long mauSo) {
        this.tuSo = tuSo;
        this.mauSo = mauSo;
    }

    public long getTuSo() {
        return tuSo;
    }

    public void setTuSo(long tuSo) {
        this.tuSo = tuSo;
    }

    public long getMauSo() {
        return mauSo;
    }

    public void setMauSo(long mauSo) {
        this.mauSo = mauSo;
    }
    public long gcd(long a, long b) {
        if(b == 0) return a;
        return gcd(b, a % b);
    }
    public void congPhanSo(PhanSo a, PhanSo b){
        long tu = a.getTuSo() * b.getMauSo() + a.getMauSo() * b.getTuSo();
        long mau = a.getMauSo() * b.getMauSo();
        this.tuSo = tu * tu;
        this.mauSo = mau * mau;
    }
    public void rutGonPhanSo(){
        long tmp = gcd(this.tuSo, this.mauSo);
        this.tuSo /= tmp;
        this.mauSo /= tmp;
    }
    public void nhanPhanSo(PhanSo ps){
        this.tuSo *= ps.getTuSo();
        this.mauSo *= ps.getMauSo();
    }
    public void print(){
        System.out.print(this.tuSo + "/" + this.mauSo + " ");
    }
}

